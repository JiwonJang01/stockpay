# setup-project.sh - StockPay 프로젝트 초기 설정 스크립트

set -e

echo "StockPay 프로젝트 설정 시작..."

# .env 파일 존재 여부 확인
if [ ! -f .env ]; then
    echo "오류: .env 파일이 없습니다."
    echo "먼저 .env 파일을 생성하고 필요한 환경변수를 설정해주세요."
    exit 1
fi

# 환경변수 로드
source .env

# 필수 환경변수 검증
required_vars=("POSTGRES_PASSWORD" "REDIS_PASSWORD" "PGADMIN_EMAIL" "PGADMIN_PASSWORD")
missing_vars=()

for var in "${required_vars[@]}"; do
    if [ -z "${!var}" ]; then
        missing_vars+=("$var")
    fi
done

if [ ${#missing_vars[@]} -ne 0 ]; then
    echo "오류: 다음 환경변수가 .env 파일에 설정되지 않았습니다:"
    printf '%s\n' "${missing_vars[@]}"
    exit 1
fi

echo "환경변수 검증 완료"

# 필수 디렉토리 생성
echo "필수 디렉토리 생성 중..."
mkdir -p logs
mkdir -p init-scripts
mkdir -p uploads
mkdir -p config/local
mkdir -p config/production

# 기존 컨테이너 중지
echo "기존 Docker 컨테이너 중지 중..."
docker-compose down 2>/dev/null || true

# 데이터 초기화 여부 확인
read -p "기존 데이터를 모두 삭제하고 새로 시작하시겠습니까? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "기존 볼륨 삭제 중..."
    docker volume prune -f
    docker-compose down -v
fi

# Docker 컨테이너 시작
echo "Docker 컨테이너 시작 중..."
docker-compose up -d

# 서비스 준비 대기
echo "서비스 준비 중... (10초 대기)"
sleep 10

# PostgreSQL 연결 대기
echo "PostgreSQL 연결 테스트 중..."
max_attempts=30
attempt=0
until docker exec stockpay-postgres pg_isready -U stockpay -d stockpay > /dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ $attempt -eq $max_attempts ]; then
        echo "PostgreSQL 연결 실패 (타임아웃)"
        exit 1
    fi
    echo "PostgreSQL 대기 중... ($attempt/$max_attempts)"
    sleep 2
done
echo "PostgreSQL 연결 성공"

# Redis 연결 대기
echo "Redis 연결 테스트 중..."
attempt=0
until docker exec stockpay-redis redis-cli -a "$REDIS_PASSWORD" ping > /dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ $attempt -eq $max_attempts ]; then
        echo "Redis 연결 실패 (타임아웃)"
        exit 1
    fi
    echo "Redis 대기 중... ($attempt/$max_attempts)"
    sleep 2
done
echo "Redis 연결 성공"

# Kafka 연결 대기
echo "Kafka 연결 테스트 중..."
attempt=0
until docker exec stockpay-kafka kafka-topics --bootstrap-server localhost:9092 --list > /dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ $attempt -eq $max_attempts ]; then
        echo "Kafka 연결 실패 (타임아웃)"
        exit 1
    fi
    echo "Kafka 대기 중... ($attempt/$max_attempts)"
    sleep 2
done
echo "Kafka 연결 성공"

# Kafka 토픽 생성
echo "Kafka 토픽 생성 중..."

# 토픽 설정: 이름:파티션수:복제수
topics=(
    "stock-price-updates:3:1"
    "buy-orders:5:1"
    "sell-orders:5:1"
    "retry-buy-orders:3:1"
    "retry-sell-orders:3:1"
    "payment-sell-orders:3:1"
    "order-notifications:2:1"
    "account-updates:3:1"
    "portfolio-updates:3:1"
    "market-data:1:1"
)

for topic_config in "${topics[@]}"; do
    IFS=':' read -r topic_name partitions replication <<< "$topic_config"

    docker exec stockpay-kafka kafka-topics \
        --bootstrap-server localhost:9092 \
        --create \
        --topic "$topic_name" \
        --partitions "$partitions" \
        --replication-factor "$replication" \
        --if-not-exists \
        --config retention.ms=604800000 \
        --config compression.type=lz4 > /dev/null 2>&1

    if [ $? -eq 0 ]; then
        echo "토픽 생성 완료: $topic_name"
    else
        echo "토픽 생성 실패: $topic_name"
    fi
done

# 생성된 토픽 목록 확인
echo ""
echo "생성된 토픽 목록:"
docker exec stockpay-kafka kafka-topics --bootstrap-server localhost:9092 --list

# 샘플 데이터 생성 (선택사항)
if [ -f "init-scripts/sample-data.sql" ]; then
    read -p "샘플 데이터를 생성하시겠습니까? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "샘플 데이터 생성 중..."
        docker exec -i stockpay-postgres psql -U stockpay -d stockpay < init-scripts/sample-data.sql
        echo "샘플 데이터 생성 완료"
    fi
fi

# 설정 완료 안내
echo ""
echo "StockPay 프로젝트 설정 완료"
echo ""
echo "관리 도구 접속 정보:"
echo "  Kafka UI:        http://localhost:8080"
echo "  Redis Commander: http://localhost:8081"
echo "  pgAdmin:         http://localhost:8082"
echo "    Email: $PGADMIN_EMAIL"
echo "    Password: [.env 파일 확인]"
echo ""
echo "다음 단계:"
echo "  1. ./gradlew build"
echo "  2. ./gradlew bootRun"
echo ""

# 현재 컨테이너 상태 확인
echo "현재 컨테이너 상태:"
docker-compose ps

echo ""
echo "설정이 완료되었습니다."