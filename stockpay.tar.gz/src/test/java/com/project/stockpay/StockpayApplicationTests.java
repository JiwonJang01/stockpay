package com.project.stockpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
